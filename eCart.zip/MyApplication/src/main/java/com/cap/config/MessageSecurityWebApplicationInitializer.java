package com.cap.config;


import org.springframework.security.web.context.*;

public class MessageSecurityWebApplicationInitializer
      extends AbstractSecurityWebApplicationInitializer {
}