package com.cap.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cart")
public class Cart {
	private Long id;
	private String name;
	private String brand;
	private float price;
	private int nos;
	
	public Cart() {
	}
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public void setId(Long id) {
		this.id = id;
	}
	

	public int getNos() {
		return nos;
	}


	public void setNos(int nos) {
		this.nos = nos;
	}


	public Cart(Long id, String name, String brand, float price, int nos) {
		super();
		this.id = id;
		this.name = name;
		this.brand = brand;
		this.price = price;
		this.nos = nos;
	}


	@Override
	public String toString() {
		return "Cart [id=" + id + ", name=" + name + ", brand=" + brand +  "price=" + price
				+ ", nos=" + nos + "]";
	}


	
}
