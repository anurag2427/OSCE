package com.cap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cap.model.Product;

public interface CartRepository extends JpaRepository<Product, Long> {
	
}
